def approval_handler(event, context):
    print("Approval received!")
    # This is where you can add logic, e.g., triggering another service or recording approval.
